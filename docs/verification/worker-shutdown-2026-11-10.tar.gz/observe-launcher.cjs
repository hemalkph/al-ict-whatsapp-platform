const cp = require('node:child_process');
const fs = require('node:fs');
const spawn = cp.spawn;
cp.spawn = function (...args) {
  const c = spawn.apply(this,args);
  if (args[0] === process.execPath) {
    const report = (event, detail = {}) => fs.writeSync(2, JSON.stringify({diagnostic:event,pid:process.pid,childPid:c.pid,...detail})+'\n');
    c.once('spawn',()=>report('launcher-child-spawn'));
    const kill = c.kill.bind(c); c.kill = (signal) => { report('launcher-child-kill',{signal}); return kill(signal); };
    c.once('exit',(code,signal)=>report('launcher-child-exit',{code,signal}));
    c.once('close',(code,signal)=>report('launcher-child-close',{code,signal}));
  }
  return c;
};
require('node:module').syncBuiltinESMExports();
