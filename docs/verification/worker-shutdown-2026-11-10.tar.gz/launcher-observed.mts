import { appendFileSync } from 'node:fs';
import { startChild, fixture } from '/Users/Projects/Class/al-ict-whatsapp-platform/src/modules/bot-worker/__fixtures__/process-harness.ts';
for (const launcher of ['tsx', 'node'] as const) for (const signal of ['SIGTERM', 'SIGINT'] as const) {
  const w = startChild(fixture, { CHILD_BLOCK_MS: '250', NODE_OPTIONS: '--require=/tmp/worker-shutdown-evidence/observe-launcher.cjs' }, launcher);
  await w.waitFor(/child-ready/);
  w.signal(signal);
  const result = await w.done;
  appendFileSync('/tmp/worker-shutdown-evidence/launcher-observed.jsonl', JSON.stringify({launcher,sentSignal:signal,...result})+'\n');
  console.log(JSON.stringify({launcher,sentSignal:signal,code:result.code,closeRecords:result.out.split('\n').filter((s)=>s.includes('launcher-child-close'))}));
}
