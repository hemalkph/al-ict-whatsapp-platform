import assert from 'node:assert/strict';
import {mkdtempSync,writeFileSync,rmSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
const directory = mkdtempSync(join(tmpdir(),'worker-env-smoke-'));
try {
  const envFile = join(directory,'synthetic.env');
  writeFileSync(envFile,'SHUTDOWN_SMOKE=loaded\nBOTS_RUNTIME_ENABLED=false\nWHATSAPP_WORKER_ENABLED=false\nWHATSAPP_OUTBOUND_ENABLED=false\nWHATSAPP_LIVE_SEND_ENABLED=false\n');
  const env = {PATH:process.env.PATH??'',NODE_ENV:'test'};
  const probe = spawnSync(process.execPath,[`--env-file-if-exists=${envFile}`,'--import','tsx','--input-type=module','-e',"import assert from 'node:assert/strict'; assert.equal(process.env.SHUTDOWN_SMOKE,'loaded'); console.log(process.cwd());"],{env,encoding:'utf8'});
  assert.equal(probe.status,0,probe.stderr);
  assert.equal(probe.stdout.trim(),process.cwd());
  for (const script of ['bots-worker','whatsapp-worker','whatsapp-outbound-worker']) {
    const r = spawnSync(process.execPath,[`--env-file-if-exists=${envFile}`,'--import','tsx',`scripts/${script}.ts`],{cwd:process.cwd(),env,encoding:'utf8'});
    assert.equal(r.status,2,r.stderr+r.stdout);assert.equal(r.signal,null);assert.doesNotMatch(r.stdout,/worker[._]started/);
    console.log(JSON.stringify({script,code:r.status,signal:r.signal,out:r.stdout+r.stderr}));
  }
  const absent = spawnSync(process.execPath,[`--env-file-if-exists=${join(directory,'absent.env')}`,'--import','tsx','scripts/bots-worker.ts'],{env,encoding:'utf8'});
  assert.equal(absent.status,2,absent.stderr);
  const pkg = JSON.parse(readFileSync('package.json','utf8')); const lock=JSON.parse(readFileSync('package-lock.json','utf8'));
  assert.equal(pkg.dependencies.tsx,'4.23.15');assert.equal(lock.packages['node_modules/tsx'].version,'4.23.15');
  for (const key of ['node_modules/tsx','node_modules/esbuild']) {assert(!lock.packages[key].dev);assert(!lock.packages[key].devOptional);}
  console.log(JSON.stringify({node:process.version,tsx:pkg.dependencies.tsx,cwd:process.cwd(),syntheticEnv:'passed',missingEnv:'passed',runtimeLock:'passed'}));
} finally {rmSync(directory,{recursive:true});}
