import { appendFileSync } from 'node:fs';
import { startChild, fixture } from '/Users/Projects/Class/al-ict-whatsapp-platform/src/modules/bot-worker/__fixtures__/process-harness.ts';
for (const block of ['0', '250']) for (const launcher of ['tsx', 'node'] as const) for (const signal of ['SIGTERM', 'SIGINT'] as const) {
  const w = startChild(fixture, { CHILD_BLOCK_MS: block }, launcher);
  await w.waitFor(/child-ready/);
  w.signal(signal);
  const result = await w.done;
  appendFileSync('/tmp/worker-shutdown-evidence/launcher.jsonl', JSON.stringify({launcher, block, ...result}) + '\n');
  console.log(JSON.stringify({launcher, block, signal, code:result.code, terminatingSignal:result.signal}));
}
